fx_version 'cerulean'
game 'gta5'

author 'Instant Mods'
description 'Elevator System'
version '1.0.0'

client_scripts {
    'client/main.lua'
}
