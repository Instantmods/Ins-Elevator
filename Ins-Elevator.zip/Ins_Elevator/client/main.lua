local elevators = {
    {
        coords = vector3(0, 0, 0),  
        floors = {
            [1] = vector3(0, 0, 10),  -- Example coordinates for floor 1
            [2] = vector3(0, 0, 20),  -- Example coordinates for floor 2
            [3] = vector3(0, 0, 30)   -- Example coordinates for floor 3
        }
    },
    
}

RegisterCommand('elevator', function(source, args, rawCommand)
    local floor = tonumber(args[1])
    if not floor then
        print("Invalid floor number.")
        return
    end

    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)

    local nearestElevator = nil
    local minDistance = math.huge
    for _, elevator in ipairs(elevators) do
        local distance = #(playerCoords - elevator.coords)
        if distance < minDistance then
            minDistance = distance
            nearestElevator = elevator
        end
    end

    if nearestElevator and minDistance < 5.0 then
        local floorCoords = nearestElevator.floors[floor]
        if floorCoords then
            SetEntityCoords(playerPed, floorCoords)
            print("Teleported to floor " .. floor)
        else
            print("Invalid floor number.")
        end
    else
        print("No elevator nearby.")
    end
end, false)
